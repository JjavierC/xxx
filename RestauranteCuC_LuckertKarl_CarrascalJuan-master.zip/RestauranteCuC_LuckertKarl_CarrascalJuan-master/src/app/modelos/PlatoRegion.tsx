export interface PlatoRegion{
    codRegion: string;
    nombreRegion: string;
}
