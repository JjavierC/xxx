export const MenuActualizar = () => {
    return (
      <>
        Soy el menú actualizar <br />
        menu...
      </>
    );
  };