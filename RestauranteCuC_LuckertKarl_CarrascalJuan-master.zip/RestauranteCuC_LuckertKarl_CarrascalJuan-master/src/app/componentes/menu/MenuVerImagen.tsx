export const MenuVerImagen = () => {
    return (
      <>
        Soy el menú ver imagen <br />
        menu...
      </>
    );
  };