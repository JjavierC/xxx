export const NoEncontrado = () => {
    return (
      <>
        Soy el No encontrado <br />
        Como el de los errores
      </>
    );
  };