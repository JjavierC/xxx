export const Inicio = () => {
  return (
  <>
  <div className="container py-5">
  <div className="row justify-content-center" style={{ marginTop: '100px' }}> {/* Ajusta el margen superior aquí */}
  <div className="col-lg-8 col-md-10">
  <div className="card shadow-lg border-0">
  <div className="card-body" style={{ backgroundColor: '#003366', color: '#FFFFFF' }}>
  <h2 className="display-4 fw-bold mb-3 text-center">Restaurante la CUC</h2>
  <p className="lead text-center">
  Sean Bienvenidos al mejor restaurante de todos los tiempos,
  <span className="fst-italic"> "Restaurante la CUC"</span>.
  </p>
  <div className="text-center mt-4">
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </>
  );
  };